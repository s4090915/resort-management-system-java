package com.customerdeal;

public interface Pricable {
    double calculatePrice();

}
