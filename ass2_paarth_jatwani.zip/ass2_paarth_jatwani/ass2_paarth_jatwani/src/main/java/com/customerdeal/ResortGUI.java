package com.customerdeal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ResortGUI extends JFrame implements ActionListener {

    private MtBullerResort resort;
    private JTabbedPane tabs;

    private JPanel mainPanel;
    private JButton btnDarkMode;
    private boolean darkMode = false;

    private JTextArea accommodationArea;
    private JButton btnDisplayAllAccommodation;
    private JButton btnDisplayAvailableAccommodation;

    private JTextField txtCustomerName;
    private JTextField txtCustomerContact;
    private JTextField txtSearchCustomer;
    private JComboBox<SkiLevel> comboSkiLevel;
    private JButton btnAddCustomer;
    private JButton btnListCustomers;
    private JButton btnSearchCustomer;
    private JTextArea customerArea;

    private JTextField txtStartDate;
    private JTextField txtDuration;
    private JComboBox<Customer> comboCustomer;
    private JComboBox<Accommodation> comboAccommodation;
    private JButton btnCreateBundle;
    private JButton btnListBundles;

    private JComboBox<TravelBundle> comboBundle;
    private JTextField txtLiftPassDays;
    private JCheckBox chkSeasonPass;
    private JTextField txtLessonCount;
    private JButton btnAddLiftPass;
    private JButton btnAddLesson;

    private JButton btnSaveBundles;
    private JButton btnLoadBundles;
    private JButton btnExit;

    private JTextArea bundleArea;

    public ResortGUI() {
        resort = new MtBullerResort();

        resort.populateAccommodations();
        resort.populateCustomers();
        resort.readBundlesFromFile();

        setTitle("Mt Buller Resort");
        setSize(1050, 750);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                exitApplication();
            }
        });

        tabs = new JTabbedPane();

        createHomeTab();
        createAccommodationTab();
        createCustomerTab();
        createBundleTab();

        add(tabs);
        setVisible(true);
    }

    private void createHomeTab() {
        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));

        JLabel title = new JLabel("Mt Buller Resort Booking System", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 30));

        JLabel subtitle = new JLabel("Managed by Paarth Companies", JLabel.CENTER);
        subtitle.setFont(new Font("Arial", Font.BOLD, 20));

        JLabel info = new JLabel("Use the tabs above to manage accommodations, customers, and travel bundles.", JLabel.CENTER);
        info.setFont(new Font("Arial", Font.PLAIN, 16));

        btnDarkMode = new JButton("Toggle Dark Mode");
        btnDarkMode.addActionListener(this);

        JPanel card = new JPanel(new GridLayout(4, 1, 10, 10));
        card.setBorder(BorderFactory.createTitledBorder("Dashboard"));
        card.add(title);
        card.add(subtitle);
        card.add(info);
        card.add(btnDarkMode);

        mainPanel.add(card, BorderLayout.CENTER);

        tabs.addTab("Home", mainPanel);
    }

    private void createAccommodationTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("Accommodation Options"));

        btnDisplayAllAccommodation = new JButton("Display All Accommodations");
        btnDisplayAvailableAccommodation = new JButton("Display Available Accommodations");

        btnDisplayAllAccommodation.addActionListener(this);
        btnDisplayAvailableAccommodation.addActionListener(this);

        buttonPanel.add(btnDisplayAllAccommodation);
        buttonPanel.add(btnDisplayAvailableAccommodation);

        accommodationArea = new JTextArea(20, 70);
        accommodationArea.setEditable(false);
        accommodationArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(accommodationArea), BorderLayout.CENTER);

        tabs.addTab("Accommodations", panel);
    }

    private void createCustomerTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Customer Details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtCustomerName = new JTextField(22);
        txtCustomerContact = new JTextField(22);
        txtSearchCustomer = new JTextField(22);
        comboSkiLevel = new JComboBox<>(SkiLevel.values());

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Customer Name:"), gbc);

        gbc.gridx = 1;
        formPanel.add(txtCustomerName, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Contact Details:"), gbc);

        gbc.gridx = 1;
        formPanel.add(txtCustomerContact, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Ski Level:"), gbc);

        gbc.gridx = 1;
        formPanel.add(comboSkiLevel, gbc);

        btnAddCustomer = new JButton("Add Customer");
        btnListCustomers = new JButton("List Customers");
        btnSearchCustomer = new JButton("Search Customer");

        btnAddCustomer.addActionListener(this);
        btnListCustomers.addActionListener(this);
        btnSearchCustomer.addActionListener(this);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(btnAddCustomer);
        buttonPanel.add(btnListCustomers);

        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search Customer"));

        gbc.gridx = 0;
        gbc.gridy = 0;
        searchPanel.add(new JLabel("Customer Name:"), gbc);

        gbc.gridx = 1;
        searchPanel.add(txtSearchCustomer, gbc);

        gbc.gridx = 2;
        searchPanel.add(btnSearchCustomer, gbc);

        JPanel topPanel = new JPanel(new BorderLayout(10, 10));
        topPanel.add(formPanel, BorderLayout.NORTH);
        topPanel.add(buttonPanel, BorderLayout.CENTER);
        topPanel.add(searchPanel, BorderLayout.SOUTH);

        customerArea = new JTextArea(18, 70);
        customerArea.setEditable(false);
        customerArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(customerArea), BorderLayout.CENTER);

        tabs.addTab("Customers", panel);
    }

    private void createBundleTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel createPanel = new JPanel(new GridBagLayout());
        createPanel.setBorder(BorderFactory.createTitledBorder("Create Travel Bundle"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        txtStartDate = new JTextField(18);
        txtDuration = new JTextField(18);

        comboCustomer = new JComboBox<>();
        comboAccommodation = new JComboBox<>();

        gbc.gridx = 0;
        gbc.gridy = 0;
        createPanel.add(new JLabel("Select Customer:"), gbc);

        gbc.gridx = 1;
        createPanel.add(comboCustomer, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        createPanel.add(new JLabel("Select Accommodation:"), gbc);

        gbc.gridx = 1;
        createPanel.add(comboAccommodation, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        createPanel.add(new JLabel("Start Date (dd/MM/yyyy):"), gbc);

        gbc.gridx = 1;
        createPanel.add(txtStartDate, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        createPanel.add(new JLabel("Duration in days (1-30):"), gbc);

        gbc.gridx = 1;
        createPanel.add(txtDuration, gbc);

        btnCreateBundle = new JButton("Create Bundle");
        btnListBundles = new JButton("List Bundles");

        btnCreateBundle.addActionListener(this);
        btnListBundles.addActionListener(this);

        JPanel createButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        createButtonPanel.add(btnCreateBundle);
        createButtonPanel.add(btnListBundles);

        JPanel extraPanel = new JPanel(new GridBagLayout());
        extraPanel.setBorder(BorderFactory.createTitledBorder("Add Extras to Bundle"));

        comboBundle = new JComboBox<>();
        txtLiftPassDays = new JTextField(18);
        chkSeasonPass = new JCheckBox("Season Pass");
        txtLessonCount = new JTextField(18);

        btnAddLiftPass = new JButton("Add Lift Pass");
        btnAddLesson = new JButton("Add Lesson Fees");

        btnAddLiftPass.addActionListener(this);
        btnAddLesson.addActionListener(this);

        gbc.gridx = 0;
        gbc.gridy = 0;
        extraPanel.add(new JLabel("Select Bundle:"), gbc);

        gbc.gridx = 1;
        extraPanel.add(comboBundle, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        extraPanel.add(new JLabel("Lift Pass Days:"), gbc);

        gbc.gridx = 1;
        extraPanel.add(txtLiftPassDays, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        extraPanel.add(new JLabel("Season Pass:"), gbc);

        gbc.gridx = 1;
        extraPanel.add(chkSeasonPass, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        extraPanel.add(new JLabel("Lesson Count:"), gbc);

        gbc.gridx = 1;
        extraPanel.add(txtLessonCount, gbc);

        JPanel extraButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        extraButtonPanel.add(btnAddLiftPass);
        extraButtonPanel.add(btnAddLesson);

        JPanel filePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filePanel.setBorder(BorderFactory.createTitledBorder("File / Exit"));

        btnSaveBundles = new JButton("Save Bundles");
        btnLoadBundles = new JButton("Load Bundles");
        btnExit = new JButton("Exit");

        btnSaveBundles.addActionListener(this);
        btnLoadBundles.addActionListener(this);
        btnExit.addActionListener(this);

        filePanel.add(btnSaveBundles);
        filePanel.add(btnLoadBundles);
        filePanel.add(btnExit);

        JPanel leftPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        leftPanel.add(createPanel);
        leftPanel.add(createButtonPanel);
        leftPanel.add(extraPanel);
        leftPanel.add(extraButtonPanel);
        leftPanel.add(filePanel);

        bundleArea = new JTextArea(22, 55);
        bundleArea.setEditable(false);
        bundleArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

        panel.add(leftPanel, BorderLayout.WEST);
        panel.add(new JScrollPane(bundleArea), BorderLayout.CENTER);

        tabs.addTab("Travel Bundles", panel);

        refreshComboBoxes();
    }

    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == btnDarkMode) {
            toggleDarkMode();
        }

        if (e.getSource() == btnDisplayAllAccommodation) {
            accommodationArea.setText(resort.displayAllAccommodations());
        }

        if (e.getSource() == btnDisplayAvailableAccommodation) {
            accommodationArea.setText(resort.displayAvailableAccommodations());
        }

        if (e.getSource() == btnAddCustomer) {
            addCustomerFromGUI();
        }

        if (e.getSource() == btnListCustomers) {
            customerArea.setText(resort.listCustomers());
        }

        if (e.getSource() == btnSearchCustomer) {
            searchCustomerFromGUI();
        }

        if (e.getSource() == btnCreateBundle) {
            createBundleFromGUI();
        }

        if (e.getSource() == btnListBundles) {
            bundleArea.setText(resort.listBundles());
        }

        if (e.getSource() == btnAddLiftPass) {
            addLiftPassFromGUI();
        }

        if (e.getSource() == btnAddLesson) {
            addLessonFromGUI();
        }

        if (e.getSource() == btnSaveBundles) {
            String message = resort.saveBundlesToFile();
            JOptionPane.showMessageDialog(this, message);
        }

        if (e.getSource() == btnLoadBundles) {
            String message = resort.readBundlesFromFile();
            bundleArea.setText(message);
            refreshComboBoxes();
        }

        if (e.getSource() == btnExit) {
            exitApplication();
        }
    }

    private void addCustomerFromGUI() {
        try {
            String name = txtCustomerName.getText().trim();
            String contact = txtCustomerContact.getText().trim();

            SkiLevel level = (SkiLevel) comboSkiLevel.getSelectedItem();

            Customer customer = resort.addCustomer(name, contact, level);

            customerArea.setText("Customer added successfully.\n");
            customerArea.append("Generated Customer ID: " + customer.getCustomerId() + "\n\n");
            customerArea.append(resort.listCustomers());

            txtCustomerName.setText("");
            txtCustomerContact.setText("");

            refreshComboBoxes();

        } catch (InvalidBookingException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void searchCustomerFromGUI() {
        String searchName = txtSearchCustomer.getText().trim();

        if (searchName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a customer name to search.");
            return;
        }

        customerArea.setText(resort.searchCustomerByName(searchName));
    }

    private void createBundleFromGUI() {
        try {
            Customer customer = (Customer) comboCustomer.getSelectedItem();
            Accommodation accommodation = (Accommodation) comboAccommodation.getSelectedItem();

            String startDate = txtStartDate.getText().trim();
            int duration = Integer.parseInt(txtDuration.getText().trim());

            TravelBundle bundle = resort.createBundle(customer, accommodation, startDate, duration);

            bundleArea.setText("Bundle created successfully.\n");
            bundleArea.append("Generated Bundle ID: " + bundle.getBundleId() + "\n\n");
            bundleArea.append(resort.listBundles());

            txtStartDate.setText("");
            txtDuration.setText("");

            refreshComboBoxes();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Duration must be a number.");
        } catch (InvalidBookingException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void addLiftPassFromGUI() {
        try {
            TravelBundle bundle = (TravelBundle) comboBundle.getSelectedItem();

            if (bundle == null) {
                JOptionPane.showMessageDialog(this, "Please create or select a bundle first.");
                return;
            }

            boolean seasonPass = chkSeasonPass.isSelected();
            int days;

            if (seasonPass) {
                days = 30;
            } else {
                days = Integer.parseInt(txtLiftPassDays.getText().trim());
            }

            resort.addLiftPassToBundle(bundle.getBundleId(), days, seasonPass);

            bundleArea.setText("Lift pass added successfully.\n\n");
            bundleArea.append(resort.listBundles());

            txtLiftPassDays.setText("");
            chkSeasonPass.setSelected(false);

            refreshComboBoxes();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Lift pass days must be a number.");
        } catch (InvalidBookingException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void addLessonFromGUI() {
        try {
            TravelBundle bundle = (TravelBundle) comboBundle.getSelectedItem();

            if (bundle == null) {
                JOptionPane.showMessageDialog(this, "Please create or select a bundle first.");
                return;
            }

            int lessonCount = Integer.parseInt(txtLessonCount.getText().trim());

            resort.addLessonToBundle(bundle.getBundleId(), lessonCount);

            bundleArea.setText("Lesson fees added successfully.\n\n");
            bundleArea.append(resort.listBundles());

            txtLessonCount.setText("");

            refreshComboBoxes();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Lesson count must be a number.");
        } catch (InvalidBookingException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void refreshComboBoxes() {
        if (comboCustomer != null) {
            comboCustomer.removeAllItems();

            for (Customer c : resort.getCustomers()) {
                comboCustomer.addItem(c);
            }
        }

        if (comboAccommodation != null) {
            comboAccommodation.removeAllItems();

            for (Accommodation a : resort.getAccommodations()) {
                if (a.isAvailable()) {
                    comboAccommodation.addItem(a);
                }
            }
        }

        if (comboBundle != null) {
            comboBundle.removeAllItems();

            for (TravelBundle b : resort.getBundles()) {
                comboBundle.addItem(b);
            }
        }
    }

    private void toggleDarkMode() {
        darkMode = !darkMode;

        Color background = darkMode ? Color.DARK_GRAY : Color.WHITE;
        Color foreground = darkMode ? Color.WHITE : Color.BLACK;

        accommodationArea.setBackground(background);
        accommodationArea.setForeground(foreground);

        customerArea.setBackground(background);
        customerArea.setForeground(foreground);

        bundleArea.setBackground(background);
        bundleArea.setForeground(foreground);

        mainPanel.setBackground(background);

        JOptionPane.showMessageDialog(this,
                darkMode ? "Dark mode enabled." : "Light mode enabled.");
    }

    private void exitApplication() {
        String message = resort.saveBundlesToFile();

        JOptionPane.showMessageDialog(this,
                message + "\nApplication will now close.");

        dispose();
        System.exit(0);
    }

    public static void main(String[] args) {
        new ResortGUI();
    }
}