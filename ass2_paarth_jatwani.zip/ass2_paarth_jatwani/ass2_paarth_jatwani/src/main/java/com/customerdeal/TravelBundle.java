package com.customerdeal;

import java.io.Serializable;

public class TravelBundle implements Serializable {
    private int bundleId;
    private Customer customer;
    private Accommodation accommodation;
    private String startDate;
    private int durationDays;
    private LiftPass liftPass;
    private Lesson lesson;

    public TravelBundle(int bundleId, Customer customer, String startDate, int durationDays) {
        this.bundleId = bundleId;
        this.customer = customer;
        this.startDate = startDate;
        this.durationDays = durationDays;
    }

    public int getBundleId() {
        return bundleId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Accommodation getAccommodation() {
        return accommodation;
    }

    public String getStartDate() {
        return startDate;
    }

    public int getDurationDays() {
        return durationDays;
    }

    public LiftPass getLiftPass() {
        return liftPass;
    }

    public Lesson getLesson() {
        return lesson;
    }

    public void setAccommodation(Accommodation accommodation) {
        this.accommodation = accommodation;
    }

    public void setLiftPass(LiftPass liftPass) {
        this.liftPass = liftPass;
    }

    public void setLesson(Lesson lesson) {
        this.lesson = lesson;
    }

    public double calculateTotalPrice() {
        double total = 0;

        if (accommodation != null) {
            total += accommodation.calculatePrice() * durationDays;
        }
        if (liftPass != null) {
            total += liftPass.calculatePrice();
        }
        if (lesson != null) {
            total += lesson.calculatePrice();
        }

        return total;
    }

    @Override
    public String toString() {
        return "Bundle ID: " + bundleId +
                "\nCustomer: " + customer.getName() +
                "\nStart Date: " + startDate +
                "\nDuration: " + durationDays + " day(s)" +
                "\nAccommodation: " + (accommodation != null ? accommodation : "None") +
                "\nLift Pass: " + (liftPass != null ? liftPass : "None") +
                "\nLesson: " + (lesson != null ? lesson : "None") +
                "\nTotal Price: $" + calculateTotalPrice();
    }
}
