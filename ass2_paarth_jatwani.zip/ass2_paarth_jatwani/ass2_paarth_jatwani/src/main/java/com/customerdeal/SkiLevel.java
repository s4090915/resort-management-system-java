package com.customerdeal;

public enum SkiLevel {
        BEGINNER,
        INTERMEDIATE,
        EXPERT
    }


